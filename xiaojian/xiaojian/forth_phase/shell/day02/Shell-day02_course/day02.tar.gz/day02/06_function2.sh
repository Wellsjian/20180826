#!/bin/bash

read -p "请输入第1个数字:" n1
read -p "请输入第2个数字:" n2
read -p "请选择操作符(+-):" op

sumx(){
    echo $[$n1+$n2]
}

subx(){
    echo $[$n1-$n2]
}

case $op in
    "+")
	    sumx
	    ;;
    "-")
	    subx
	    ;;
    *)
	    echo "操作符无效,请输入(+-)!"

esac




















