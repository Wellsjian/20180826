#!/bin/bash

while :
do
   # 提取连接数
   count=`mysqladmin -uroot -p123456 status | awk '{print $4}'`
   echo "`date +%F` 并发连接数为: $count"
   sleep 2

done
