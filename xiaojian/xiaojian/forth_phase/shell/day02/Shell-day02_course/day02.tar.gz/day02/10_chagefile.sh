#!/bin/bash

for filename in `ls *.txt`
do
    # file1.txt  -->  file1.doc
    name=${filename%.txt}
    mv $filename $name.doc
done
