#!/bin/bash

# root:x:0:0:root:/root:/bin/bash
for line in `head -10 /etc/passwd`
do
    echo ${line%%:*}
done
