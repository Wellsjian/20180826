#!/bin/bash

# 输入一个字符,判断是数字、字母还是其他字符
read -p "请输入一个字符:" char

# 判断用户输入是否为一个字符
if [ ${#char} -ne 1 ];then
    echo "你输入的不是一个字符!"
    exit
fi


case $char in
    [0-9])
            echo "$char 是一个数字"
	    ;;
    [a-Z])
	    echo "$char 是一个字母"
	    ;;
    *)
	    echo "$char 是一个特殊字符"
	    ;;

esac







