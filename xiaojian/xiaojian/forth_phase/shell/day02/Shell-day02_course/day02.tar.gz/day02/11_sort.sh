#!/bin/bash

read -p "请输入第一个整数:" n1
read -p "请输入第二个整数:" n2
read -p "请输入第三个整数:" n3

# 1.保证n1是最小值
if [ $n1 -ge $n2 ];then
    temp=$n1 n1=$n2 n2=$temp
fi
if [ $n1 -ge $n3 ];then
    temp=$n1 n1=$n3 n3=$temp
fi
# 2.判断n2和n3
if [ $n2 -ge $n3 ];then
    temp=$n2 n2=$n3 n3=$temp
fi

echo "排序后:$n1 $n2 $n3"



















