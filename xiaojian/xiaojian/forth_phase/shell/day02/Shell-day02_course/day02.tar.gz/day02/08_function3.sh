#!/bin/bash

makedir(){
    read -p "请输入目录名:" dirname
    directory="/home/tarena/$dirname"
    if [ -e $directory ];then
        echo $directory 已存在
    else
        mkdir $directory
        echo 创建成功	
    fi
}

makedir
