#!/bin/bash

star(){
    echo "***********"        
}

star
star

