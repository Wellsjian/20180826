#!/usr/bin/env python3

def add_info():
    print('I am add_info')

def modify_info():
    print('I am modify_info')

def delete_info():
    print('I am delete_info')

menu = '''1. 添加学生信息
2. 修改学生信息
3. 删除学生信息
请选择(1/2/3):'''
choice = input(menu).strip()

if choice in ['1','2','3']:
    cmd_dict = {
        '1' : add_info,
        '2' : modify_info,
        '3' : delete_info
    }
    cmd_dict[choice]()
else:
    print('无效的选择')





















