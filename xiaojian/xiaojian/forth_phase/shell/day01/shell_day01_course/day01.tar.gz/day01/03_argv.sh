#!/bin/bash

echo $1
echo $2
echo $3
echo $4

echo $#
echo $*
echo $?

echo $1 + $2









