#!/bin/bash

read -t 5 -p "请输入姓名:" name
echo "你输入的姓名是:$name"
