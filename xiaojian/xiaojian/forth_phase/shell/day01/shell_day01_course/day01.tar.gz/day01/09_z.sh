#!/bin/bash

read -p "请输入用户名:" username

[ -z $username ] && exit

sudo useradd $username
