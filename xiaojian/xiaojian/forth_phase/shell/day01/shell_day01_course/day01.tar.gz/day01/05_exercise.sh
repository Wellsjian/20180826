#!/bin/bash
read -p "输入学生姓名:" name
read -p "输入学生成绩:" score
echo "$name的成绩为$score分"
