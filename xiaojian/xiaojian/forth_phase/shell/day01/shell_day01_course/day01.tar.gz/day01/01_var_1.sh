#!/bin/bash

name="风云雄霸天下"
echo $name
echo "$name真好看呀"
echo '$name真好看呀'

name="赵敏"
age=20
echo "$name今年$age岁"











