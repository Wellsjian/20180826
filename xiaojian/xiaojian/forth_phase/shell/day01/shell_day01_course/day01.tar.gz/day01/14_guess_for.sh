#!/bin/bash

# 1.电脑生成数字:1-10000之间
computer=$[RANDOM%10000+1]

for i in {1..30}
do
    read -p "请猜数字:" you
    if [ $you -eq $computer ];then
        echo "猜对了"
	exit
    elif [ $you -lt $computer ];then
	echo "猜小了"
    else
	echo "猜大了"
    fi
done
