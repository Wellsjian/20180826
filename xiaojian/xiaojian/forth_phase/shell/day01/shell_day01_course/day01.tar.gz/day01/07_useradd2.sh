#!/bin/bash

sudo useradd $1
echo "$1创建成功"
