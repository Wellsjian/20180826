#!/bin/bash

# 生成1-5之间的随机整数
computer=$[RANDOM%5+1]
echo $computer

read -p "请猜数字:" you

if [ $you -eq $computer ];then
    echo '恭喜,猜对了!'
    exit
elif [ $you -lt $computer ];then
    echo '猜小了'
else
    echo '猜大了'
fi
