#!/bin/bash

if [ $USER == tarena ];then
    echo "恭喜,你是tarena"
else
    echo "你是其他用户"
fi
