#!/bin/bash

#i=1
#let i++
#echo $i

#sum=`expr $1 + $2`
#echo "$1 + $2 = $sum"

i=100
echo $[5+10]
echo $[i+i]
echo $[$1+$2+$3]












