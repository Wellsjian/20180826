#!/bin/bash

# 定义常用变量
file="file.txt"

# 1.获取到行数
number=$(sed -n '$=' $file)
# 2.整体逻辑
while :
do
    clear
    n=$[RANDOM%number+1]
    sed -n "${n}p" $file
    sleep 1
done









