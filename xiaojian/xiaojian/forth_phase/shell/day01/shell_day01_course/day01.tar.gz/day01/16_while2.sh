#!/bin/bash

# 简陋的计时器
i=1

while :
do
    echo $i
    let i++
    sleep 1
    clear
done
