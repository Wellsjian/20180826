#!/bin/bash

# 打印1-100之间的偶数
for num in `seq 2 2 100`
do
    echo $num
done
