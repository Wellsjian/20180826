#!/bin/bash
# 打印1-5之间的整数
for i in {1..5}
do
    echo $i
done


for file in `ls *.sh`
do
    echo $file
done

